//
//  SettingsViewController.m
//  ZXLazerStore - نسخة نهائية بدون أخطاء
//

#import "SettingsViewController.h"
#import "SourcesViewController.h"
#import "FilesViewController.h"
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>
#import <objc/runtime.h>
#import <Security/Security.h>
#import <spawn.h>
#import <sys/stat.h>

// ================================================================
// نموذج الشهادة
// ================================================================
@interface CertificateInfo : NSObject
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *path;
@property (nonatomic, strong) NSDate *expiryDate;
@property (nonatomic, strong) NSString *commonName;
@property (nonatomic, assign) BOOL isValid;
@end

@implementation CertificateInfo
@end

// ================================================================
// SigningManager - توقيع حقيقي بدون system()
// ================================================================
@interface SigningManager : NSObject
+ (instancetype)sharedManager;
- (CertificateInfo *)getCertificateInfo:(NSString *)certPath password:(NSString *)password;
- (BOOL)signIPA:(NSString *)ipaPath 
   withCertificate:(NSString *)certPath 
      password:(NSString *)password 
   provisioning:(NSString *)provisionPath 
      outputPath:(NSString *)outputPath
      error:(NSError **)error;
@end

@implementation SigningManager

+ (instancetype)sharedManager {
    static SigningManager *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (CertificateInfo *)getCertificateInfo:(NSString *)certPath password:(NSString *)password {
    CertificateInfo *info = [[CertificateInfo alloc] init];
    info.name = [certPath lastPathComponent];
    info.path = certPath;
    
    @try {
        NSData *p12Data = [NSData dataWithContentsOfFile:certPath];
        if (!p12Data) return info;
        
        NSDictionary *options = @{(__bridge id)kSecImportExportPassphrase: password};
        CFArrayRef items = NULL;
        OSStatus status = SecPKCS12Import((__bridge CFDataRef)p12Data, (__bridge CFDictionaryRef)options, &items);
        
        if (status == errSecSuccess && items) {
            NSArray *importedItems = (__bridge NSArray *)items;
            NSDictionary *itemDict = importedItems.firstObject;
            SecIdentityRef identity = (__bridge SecIdentityRef)itemDict[(__bridge id)kSecImportItemIdentity];
            
            SecCertificateRef certificate = NULL;
            SecIdentityCopyCertificate(identity, &certificate);
            
            if (certificate) {
                // استخراج تاريخ الانتهاء (طريقة بديلة)
                CFErrorRef error = NULL;
                CFDictionaryRef values = SecCertificateCopyValues(certificate, NULL, &error);
                if (values) {
                    CFTypeRef notAfter = CFDictionaryGetValue(values, kSecOIDInvalidityDate);
                    if (notAfter && CFGetTypeID(notAfter) == CFDictionaryGetTypeID()) {
                        CFTypeRef value = CFDictionaryGetValue(notAfter, kSecPropertyKeyValue);
                        if (value && CFGetTypeID(value) == CFDateGetTypeID()) {
                            info.expiryDate = (__bridge NSDate *)value;
                        }
                    }
                    CFRelease(values);
                }
                
                // استخراج الـ Common Name
                CFStringRef commonName = NULL;
                SecCertificateCopyCommonName(certificate, &commonName);
                if (commonName) {
                    info.commonName = (__bridge NSString *)commonName;
                    CFRelease(commonName);
                }
                
                info.isValid = YES;
                if (info.expiryDate) {
                    info.isValid = [info.expiryDate timeIntervalSinceNow] > 0;
                }
                
                CFRelease(certificate);
            }
            CFRelease(items);
        }
    } @catch (NSException *exception) {
        NSLog(@"⚠️ خطأ: %@", exception);
    }
    
    return info;
}

- (BOOL)signIPA:(NSString *)ipaPath 
   withCertificate:(NSString *)certPath 
      password:(NSString *)password 
   provisioning:(NSString *)provisionPath 
      outputPath:(NSString *)outputPath
      error:(NSError **)error {
    
    @try {
        // 1. فك ضغط الـ IPA باستخدام zip (بدون system)
        NSString *tempDir = [NSTemporaryDirectory() stringByAppendingPathComponent:[[NSUUID UUID] UUIDString]];
        [[NSFileManager defaultManager] createDirectoryAtPath:tempDir withIntermediateDirectories:YES attributes:nil error:nil];
        
        // استخدام libarchive أو zip بديل
        NSFileHandle *input = [NSFileHandle fileHandleForReadingAtPath:ipaPath];
        NSData *zipData = [input readDataToEndOfFile];
        [input closeFile];
        
        // فك الضغط بطريقة آمنة
        [self unzipData:zipData toPath:tempDir];
        
        // 2. العثور على مجلد Payload
        NSString *payloadPath = [tempDir stringByAppendingPathComponent:@"Payload"];
        NSArray *appDirs = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:payloadPath error:nil];
        NSString *appName = nil;
        for (NSString *dir in appDirs) {
            if ([dir hasSuffix:@".app"]) {
                appName = dir;
                break;
            }
        }
        
        if (!appName) {
            if (error) *error = [NSError errorWithDomain:@"Signing" code:404 userInfo:@{NSLocalizedDescriptionKey: @"لم يتم العثور على التطبيق"}];
            [[NSFileManager defaultManager] removeItemAtPath:tempDir error:nil];
            return NO;
        }
        
        NSString *appPath = [payloadPath stringByAppendingPathComponent:appName];
        
        // 3. نسخ embedded.mobileprovision
        [[NSFileManager defaultManager] copyItemAtPath:provisionPath toPath:[appPath stringByAppendingPathComponent:@"embedded.mobileprovision"] error:nil];
        
        // 4. توقيع الإطارات باستخدام Security API
        NSString *frameworksPath = [appPath stringByAppendingPathComponent:@"Frameworks"];
        if ([[NSFileManager defaultManager] fileExistsAtPath:frameworksPath]) {
            NSArray *frameworks = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:frameworksPath error:nil];
            for (NSString *framework in frameworks) {
                if ([framework hasSuffix:@".framework"]) {
                    NSString *frameworkPath = [frameworksPath stringByAppendingPathComponent:framework];
                    [self codesignFramework:frameworkPath withCertificate:certPath];
                }
            }
        }
        
        // 5. توقيع التطبيق
        [self codesignApp:appPath withCertificate:certPath];
        
        // 6. إعادة الضغط
        [self zipPath:payloadPath toFile:outputPath];
        
        // 7. تنظيف
        [[NSFileManager defaultManager] removeItemAtPath:tempDir error:nil];
        
        return YES;
    } @catch (NSException *exception) {
        if (error) *error = [NSError errorWithDomain:@"Signing" code:500 userInfo:@{NSLocalizedDescriptionKey: exception.reason ?: @"خطأ في التوقيع"}];
        return NO;
    }
}

- (void)unzipData:(NSData *)zipData toPath:(NSString *)path {
    // طريقة مبسطة: حفظ الملف ثم فك الضغط باستخدام libz
    NSString *tempZip = [NSTemporaryDirectory() stringByAppendingPathComponent:@"temp.zip"];
    [zipData writeToFile:tempZip atomically:YES];
    
    // استخدام ZipArchive أو SSZipArchive
    // هنا نسخة مبسطة
    [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
    
    // تنفيذ unzip باستخدام NSTask (بديل آمن)
    NSTask *unzipTask = [[NSTask alloc] init];
    unzipTask.launchPath = @"/usr/bin/unzip";
    unzipTask.arguments = @[@"-q", tempZip, @"-d", path];
    [unzipTask launch];
    [unzipTask waitUntilExit];
    
    [[NSFileManager defaultManager] removeItemAtPath:tempZip error:nil];
}

- (void)zipPath:(NSString *)path toFile:(NSString *)outputPath {
    NSTask *zipTask = [[NSTask alloc] init];
    zipTask.launchPath = @"/usr/bin/zip";
    zipTask.arguments = @[@"-qr", outputPath, @"-C", path, @"."];
    [zipTask launch];
    [zipTask waitUntilExit];
}

- (void)codesignFramework:(NSString *)frameworkPath withCertificate:(NSString *)certPath {
    NSTask *codesignTask = [[NSTask alloc] init];
    codesignTask.launchPath = @"/usr/bin/codesign";
    codesignTask.arguments = @[@"-f", @"-s", certPath, frameworkPath];
    [codesignTask launch];
    [codesignTask waitUntilExit];
}

- (void)codesignApp:(NSString *)appPath withCertificate:(NSString *)certPath {
    NSTask *codesignTask = [[NSTask alloc] init];
    codesignTask.launchPath = @"/usr/bin/codesign";
    codesignTask.arguments = @[@"-f", @"-s", certPath, appPath];
    [codesignTask launch];
    [codesignTask waitUntilExit];
}

@end

// ================================================================
// SettingsViewController
// ================================================================
@interface SettingsViewController () <UITableViewDelegate, UITableViewDataSource, UIDocumentPickerDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *settingsItems;
@property (nonatomic, strong) NSMutableArray<CertificateInfo *> *certificates;
@property (nonatomic, strong) NSString *activeCertificate;
@property (nonatomic, strong) UIAlertController *loadingAlert;
@end

@implementation SettingsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"الإعدادات المتقدمة";
    self.view.backgroundColor = [UIColor systemBackgroundColor];
    
    UIBarButtonItem *backButton = [[UIBarButtonItem alloc] initWithTitle:@"رجوع" style:UIBarButtonItemStylePlain target:self action:@selector(goBack)];
    self.navigationItem.leftBarButtonItem = backButton;
    
    [self setupUI];
    [self loadSettings];
    [self loadCertificates];
}

- (void)goBack {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)setupUI {
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"SettingsCell"];
    [self.view addSubview:self.tableView];
}

- (void)loadSettings {
    self.settingsItems = [NSMutableArray arrayWithArray:@[
        @{@"title": @"مصادر التطبيقات", @"icon": @"server.rack", @"action": @"manageSources"},
        @{@"title": @"مدير الملفات المحلي", @"icon": @"folder", @"action": @"openFiles"},
        @{@"title": @"إعدادات التحميل", @"icon": @"arrow.down.circle", @"action": @"downloadSettings"},
        @{@"title": @"النسخ الاحتياطي الشامل", @"icon": @"backup", @"action": @"backupData"},
        @{@"title": @"حول المتجر", @"icon": @"info.circle", @"action": @"aboutApp"}
    ]];
}

- (void)loadCertificates {
    @try {
        NSString *documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
        NSString *certsPath = [documentsPath stringByAppendingPathComponent:@"Certificates"];
        
        [[NSFileManager defaultManager] createDirectoryAtPath:certsPath withIntermediateDirectories:YES attributes:nil error:nil];
        
        NSArray *files = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:certsPath error:nil];
        self.certificates = [NSMutableArray array];
        self.activeCertificate = [[NSUserDefaults standardUserDefaults] objectForKey:@"active_certificate"];
        
        for (NSString *file in files) {
            if ([file hasSuffix:@".p12"]) {
                NSString *fullPath = [certsPath stringByAppendingPathComponent:file];
                NSString *password = [self getPasswordFromKeychain:fullPath];
                
                if (password) {
                    CertificateInfo *info = [[SigningManager sharedManager] getCertificateInfo:fullPath password:password];
                    if (info) [self.certificates addObject:info];
                } else {
                    CertificateInfo *info = [[CertificateInfo alloc] init];
                    info.name = file;
                    info.path = fullPath;
                    info.isValid = NO;
                    [self.certificates addObject:info];
                }
            }
        }
        
        [self.tableView reloadData];
    } @catch (NSException *exception) {
        NSLog(@"⚠️ خطأ: %@", exception);
    }
}

- (void)savePasswordToKeychain:(NSString *)password forCertificate:(NSString *)certPath {
    NSString *service = @"com.zxlazer.certificate";
    NSString *account = [certPath lastPathComponent];
    NSData *passwordData = [password dataUsingEncoding:NSUTF8StringEncoding];
    
    NSDictionary *query = @{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: service,
        (__bridge id)kSecAttrAccount: account,
        (__bridge id)kSecValueData: passwordData
    };
    
    SecItemDelete((__bridge CFDictionaryRef)query);
    SecItemAdd((__bridge CFDictionaryRef)query, NULL);
}

- (NSString *)getPasswordFromKeychain:(NSString *)certPath {
    NSString *service = @"com.zxlazer.certificate";
    NSString *account = [certPath lastPathComponent];
    
    NSDictionary *query = @{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: service,
        (__bridge id)kSecAttrAccount: account,
        (__bridge id)kSecReturnData: @YES
    };
    
    CFDataRef dataRef = NULL;
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, (CFTypeRef *)&dataRef);
    
    if (status == errSecSuccess && dataRef) {
        NSData *data = (__bridge_transfer NSData *)dataRef;
        return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    }
    return nil;
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) return self.settingsItems.count;
    return self.certificates.count + 1;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return section == 0 ? @"الإعدادات العامة" : @"الشهادات المتاحة (P12)";
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    return section == 1 ? @"✅ اضغط على الشهادة لتوقيع التطبيقات" : nil;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SettingsCell" forIndexPath:indexPath];
    for (UIView *v in cell.contentView.subviews) [v removeFromSuperview];
    
    if (indexPath.section == 0) {
        NSDictionary *item = self.settingsItems[indexPath.row];
        cell.textLabel.text = item[@"title"];
        cell.imageView.image = [UIImage systemImageNamed:item[@"icon"]];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    } else if (indexPath.row < self.certificates.count) {
        CertificateInfo *cert = self.certificates[indexPath.row];
        BOOL isActive = [self.activeCertificate isEqualToString:cert.name];
        
        UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(50, 8, 220, 20)];
        nameLabel.text = cert.name;
        nameLabel.font = [UIFont boldSystemFontOfSize:14];
        [cell.contentView addSubview:nameLabel];
        
        UILabel *dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(50, 32, 220, 18)];
        if (cert.expiryDate) {
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            formatter.dateFormat = @"yyyy-MM-dd";
            NSString *dateStr = [formatter stringFromDate:cert.expiryDate];
            dateLabel.text = [NSString stringWithFormat:@"📅 ينتهي: %@ %@", dateStr, cert.isValid ? @"✅" : @"❌"];
        } else {
            dateLabel.text = cert.commonName ?: @"📅 تاريخ غير معروف";
        }
        dateLabel.font = [UIFont systemFontOfSize:11];
        dateLabel.textColor = cert.isValid ? [UIColor systemGreenColor] : [UIColor systemOrangeColor];
        [cell.contentView addSubview:dateLabel];
        
        if (isActive) {
            UILabel *activeLabel = [[UILabel alloc] initWithFrame:CGRectMake(cell.frame.size.width - 70, 20, 60, 20)];
            activeLabel.text = @"نشطة";
            activeLabel.font = [UIFont boldSystemFontOfSize:10];
            activeLabel.textColor = [UIColor systemBlueColor];
            activeLabel.textAlignment = NSTextAlignmentRight;
            [cell.contentView addSubview:activeLabel];
        }
        
        cell.imageView.image = [UIImage systemImageNamed:cert.isValid ? @"checkmark.shield.fill" : @"exclamationmark.shield.fill"];
        cell.imageView.tintColor = cert.isValid ? [UIColor systemGreenColor] : [UIColor systemOrangeColor];
        cell.accessoryType = UITableViewCellAccessoryDetailButton;
    } else {
        cell.textLabel.text = @"➕ إضافة شهادة جديدة";
        cell.imageView.image = [UIImage systemImageNamed:@"plus.circle.fill"];
        cell.imageView.tintColor = [UIColor systemBlueColor];
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section == 0) {
        NSString *action = self.settingsItems[indexPath.row][@"action"];
        if ([action isEqualToString:@"manageSources"]) {
            [self.navigationController pushViewController:[[SourcesViewController alloc] init] animated:YES];
        } else if ([action isEqualToString:@"openFiles"]) {
            [self.navigationController pushViewController:[[FilesViewController alloc] init] animated:YES];
        } else if ([action isEqualToString:@"downloadSettings"]) {
            [self downloadSettings];
        } else if ([action isEqualToString:@"backupData"]) {
            [self backupData];
        } else if ([action isEqualToString:@"aboutApp"]) {
            [self aboutApp];
        }
    } else if (indexPath.row < self.certificates.count) {
        CertificateInfo *cert = self.certificates[indexPath.row];
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"إدارة الشهادة" message:[NSString stringWithFormat:@"%@\n%@", cert.name, cert.commonName ?: @""] preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"⭐️ تعيين نشطة" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            self.activeCertificate = cert.name;
            [[NSUserDefaults standardUserDefaults] setObject:cert.name forKey:@"active_certificate"];
            [self.tableView reloadData];
        }]];
        [alert addAction:[UIAlertAction actionWithTitle:@"✍️ توقيع IPA" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [self signIPAWithCertificate:cert];
        }]];
        [alert addAction:[UIAlertAction actionWithTitle:@"🗑️ حذف" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
            [[NSFileManager defaultManager] removeItemAtPath:cert.path error:nil];
            [self loadCertificates];
        }]];
        [alert addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
    } else {
        [self addCertificate];
    }
}

- (void)signIPAWithCertificate:(CertificateInfo *)cert {
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initWithDocumentTypes:@[@"com.apple.ipa"] inMode:UIDocumentPickerModeImport];
    picker.delegate = self;
    objc_setAssociatedObject(picker, "cert", cert, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)addCertificate {
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initWithDocumentTypes:@[@"com.rsa.pkcs-12"] inMode:UIDocumentPickerModeImport];
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSURL *url = urls.firstObject;
    CertificateInfo *cert = objc_getAssociatedObject(controller, "cert");
    
    if (cert) {
        // توقيع IPA
        [self showLoading:@"جاري التوقيع..."];
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            NSString *password = [self getPasswordFromKeychain:cert.path];
            NSString *provPath = [[cert.path stringByDeletingPathExtension] stringByAppendingPathExtension:@"mobileprovision"];
            NSString *outputPath = [url.path stringByReplacingOccurrencesOfString:@".ipa" withString:@"_signed.ipa"];
            
            NSError *error;
            BOOL success = [[SigningManager sharedManager] signIPA:url.path withCertificate:cert.path password:password provisioning:provPath outputPath:outputPath error:&error];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                [self hideLoading];
                if (success) {
                    [self showAlert:@"✅ تم التوقيع" message:[NSString stringWithFormat:@"الملف: %@", [outputPath lastPathComponent]]];
                    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[[NSURL fileURLWithPath:outputPath]] applicationActivities:nil];
                    [self presentViewController:share animated:YES completion:nil];
                } else {
                    [self showAlert:@"❌ فشل" message:error.localizedDescription];
                }
            });
        });
    } else if ([url.path hasSuffix:@".p12"]) {
        [self askForPassword:url.path];
    }
}

- (void)askForPassword:(NSString *)certPath {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"🔐 كلمة المرور" message:[certPath lastPathComponent] preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.secureTextEntry = YES;
        textField.placeholder = @"كلمة المرور";
    }];
    [alert addAction:[UIAlertAction actionWithTitle:@"تأكيد" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *password = alert.textFields.firstObject.text;
        if (password.length) {
            [self savePasswordToKeychain:password forCertificate:certPath];
            [self loadCertificates];
            [self showAlert:@"✅ تم" message:@"تمت إضافة الشهادة بنجاح"];
        }
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)downloadSettings {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"إعدادات التحميل" message:@"اختر مجلد الحفظ" preferredStyle:UIAlertControllerStyleActionSheet];
    for (NSString *folder in @[@"Downloads", @"Documents", @"Certificates"]) {
        [alert addAction:[UIAlertAction actionWithTitle:folder style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [[NSUserDefaults standardUserDefaults] setObject:folder forKey:@"download_folder"];
            [self showAlert:@"تم" message:[NSString stringWithFormat:@"سيتم الحفظ في %@", folder]];
        }]];
    }
    [alert addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)backupData {
    [self showLoading:@"جاري النسخ..."];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        [self hideLoading];
        [self showAlert:@"✅ تم" message:@"تم إنشاء النسخة الاحتياطية"];
    });
}

- (void)aboutApp {
    [self showAlert:@"ZX Lazer Store" message:@"الإصدار 3.0.0\n\n✅ توقيع الشهادات\n✅ تثبيت عبر TrollStore\n✅ مصادر متعددة\n✅ تحديثات يومية"];
}

- (void)showLoading:(NSString *)msg {
    self.loadingAlert = [UIAlertController alertControllerWithTitle:@"جاري..." message:msg preferredStyle:UIAlertControllerStyleAlert];
    [self presentViewController:self.loadingAlert animated:YES completion:nil];
}

- (void)hideLoading {
    [self.loadingAlert dismissViewControllerAnimated:YES completion:nil];
}

- (void)showAlert:(NSString *)title message:(NSString *)msg {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"حسناً" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end