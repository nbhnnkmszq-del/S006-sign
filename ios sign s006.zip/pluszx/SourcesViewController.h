//
//  SourcesViewController.h
//  ZXLazerStore - إدارة مصادر التطبيقات
//

#import <UIKit/UIKit.h>

@interface SourcesViewController : UIViewController

// الدوال اللي بنحتاجها لو استدعيناها من مكان ثاني
- (void)loadSources;
- (void)fetchAppsFromSource:(NSString *)sourceURL;

@end