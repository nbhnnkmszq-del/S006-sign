#import "CategoryViewController.h"
#import "AppDetailViewController.h"

@implementation CategoryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // إعداد العنوان والخلفية
    self.title = self.categoryName ?: @"التصنيفات 🔥";
    self.navigationController.navigationBar.prefersLargeTitles = YES;
    self.view.backgroundColor = [UIColor systemGroupedBackgroundColor];
    
    [self setupTableView];
    [self loadCategoryData];
    [self setupRefreshControl];
}

- (void)setupTableView {
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleInsetGrouped];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.rowHeight = 90; // زيادة الارتفاع ليعطي فخامة
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
    [self.view addSubview:self.tableView];
}

- (void)setupRefreshControl {
    UIRefreshControl *refreshControl = [[UIRefreshControl alloc] init];
    refreshControl.tintColor = [UIColor systemBlueColor];
    [refreshControl addTarget:self action:@selector(loadCategoryData) forControlEvents:UIControlEventValueChanged];
    self.tableView.refreshControl = refreshControl;
}

- (void)loadCategoryData {
    // مصفوفة البيانات (محاكاة لجلب البيانات من سيرفر مسلط)
    self.apps = [[NSMutableArray alloc] init];
    
    // بيانات تجريبية (يتم تعويضها بـ JSON لاحقاً)
    NSArray *mockData = @[
        @{@"name": @"Snapchat Plus", @"ver": @"13.20.0", @"dev": @"LazerTeam", @"icon": @"snap_icon"},
        @{@"name": @"Instagram Rocket", @"ver": @"320.1", @"dev": @"RocketDev", @"icon": @"ig_icon"},
        @{@"name": @"WhatsApp Watusi", @"ver": @"24.5.10", @"dev": @"Fouad", @"icon": @"wa_icon"},
        @{@"name": @"TikTok Unicorn", @"ver": @"33.1.0", @"dev": @"Unicorn", @"icon": @"tk_icon"}
    ];
    
    [self.apps addObjectsFromArray:mockData];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
        [self.tableView.refreshControl endRefreshing];
    });
}

#pragma mark - TableView Methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.apps.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"CategoryCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.layer.cornerRadius = 12;
        cell.clipsToBounds = YES;
    }
    
    NSDictionary *app = self.apps[indexPath.row];
    
    // تنسيق النص الرئيسي
    cell.textLabel.text = app[@"name"];
    cell.textLabel.font = [UIFont boldSystemFontOfSize:19];
    
    // تنسيق النص الفرعي
    cell.detailTextLabel.text = [NSString stringWithFormat:@"الإصدار: %@ | المطور: %@", app[@"ver"], app[@"dev"]];
    cell.detailTextLabel.textColor = [UIColor secondaryLabelColor];
    
    // أيقونة افتراضية فخمة
    if (@available(iOS 13.0, *)) {
        cell.imageView.image = [UIImage systemImageNamed:@"app.badge.fill"];
        cell.imageView.tintColor = [UIColor systemBlueColor];
    }
    
    // إضافة زر "تثبيت" صغير في الخلية
    UIButton *installBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [installBtn setTitle:@"تثبيت" forState:UIControlStateNormal];
    installBtn.backgroundColor = [UIColor systemBlueColor];
    [installBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    installBtn.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    installBtn.layer.cornerRadius = 15;
    installBtn.frame = CGRectMake(0, 0, 70, 30);
    cell.accessoryView = installBtn;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    // كود الانتقال لصفحة التفاصيل (AppDetailViewController)
    AppDetailViewController *detailVC = [[AppDetailViewController alloc] init];
    NSDictionary *selectedApp = self.apps[indexPath.row];
    detailVC.title = selectedApp[@"name"];
    
    [self.navigationController pushViewController:detailVC animated:YES];
}

// دالة إضافية لجعل الجدول يتحرك بسلاسة (Animation)
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    cell.transform = CGAffineTransformMakeTranslation(0, 40);
    cell.alpha = 0;
    [UIView animateWithDuration:0.4 delay:0.05 * indexPath.row options:UIViewAnimationOptionCurveEaseInOut animations:^{
        cell.transform = CGAffineTransformIdentity;
        cell.alpha = 1;
    } completion:nil];
}

@end