#import "AppDetailViewController.h"
#import "zxlazerRootViewController.h"

@interface AppDetailViewController ()
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIImageView *iconView;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *versionLabel;
@property (nonatomic, strong) UILabel *bundleLabel;
@property (nonatomic, strong) UITextView *descriptionView;
@property (nonatomic, strong) UIButton *installButton;
@property (nonatomic, strong) UIProgressView *progressView;
@property (nonatomic, strong) UILabel *progressLabel;
@property (nonatomic, strong) UIView *progressContainer;
@property (nonatomic, strong) NSURLSessionDownloadTask *currentDownloadTask;
@end

// تعريف الواجهة للمثبت ليعرفها المترجم
@interface IPAInstaller : NSObject
+ (instancetype)sharedInstaller;
- (void)installIPAAtPath:(NSString *)ipaPath progress:(void(^)(float progress, NSString *status))progressBlock completion:(void(^)(BOOL success, NSError *error))completion;
@end

@implementation AppDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"تفاصيل التطبيق";
    self.view.backgroundColor = [UIColor systemBackgroundColor];
    [self setupUI];
    [self loadAppDetails];
}

- (void)setupUI {
    CGFloat width = self.view.frame.size.width;
    CGFloat y = 20;
    
    self.scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    self.scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:self.scrollView];
    
    self.iconView = [[UIImageView alloc] initWithFrame:CGRectMake(width/2 - 60, y, 120, 120)];
    self.iconView.backgroundColor = [UIColor systemGray5Color];
    self.iconView.layer.cornerRadius = 25;
    self.iconView.clipsToBounds = YES;
    self.iconView.image = [UIImage systemImageNamed:@"app.fill"];
    [self.scrollView addSubview:self.iconView];
    
    y += 140;
    self.nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, y, width - 40, 35)];
    self.nameLabel.font = [UIFont boldSystemFontOfSize:26];
    self.nameLabel.textAlignment = NSTextAlignmentCenter;
    [self.scrollView addSubview:self.nameLabel];
    
    y += 45;
    self.versionLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, y, width - 40, 20)];
    self.versionLabel.font = [UIFont systemFontOfSize:14];
    self.versionLabel.textColor = [UIColor secondaryLabelColor];
    self.versionLabel.textAlignment = NSTextAlignmentCenter;
    [self.scrollView addSubview:self.versionLabel];
    
    y += 25;
    self.bundleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, y, width - 40, 20)];
    self.bundleLabel.font = [UIFont systemFontOfSize:12];
    self.bundleLabel.textColor = [UIColor tertiaryLabelColor];
    self.bundleLabel.textAlignment = NSTextAlignmentCenter;
    [self.scrollView addSubview:self.bundleLabel];
    
    y += 40;
    self.descriptionView = [[UITextView alloc] initWithFrame:CGRectMake(20, y, width - 40, 120)];
    self.descriptionView.font = [UIFont systemFontOfSize:15];
    self.descriptionView.editable = NO;
    self.descriptionView.textAlignment = NSTextAlignmentCenter;
    self.descriptionView.backgroundColor = [UIColor clearColor];
    [self.scrollView addSubview:self.descriptionView];
    
    y += 130;
    self.progressContainer = [[UIView alloc] initWithFrame:CGRectMake(20, y, width - 40, 70)];
    self.progressContainer.backgroundColor = [UIColor systemGray6Color];
    self.progressContainer.layer.cornerRadius = 12;
    self.progressContainer.hidden = YES;
    [self.scrollView addSubview:self.progressContainer];
    
    self.progressView = [[UIProgressView alloc] initWithFrame:CGRectMake(15, 20, self.progressContainer.frame.size.width - 30, 10)];
    [self.progressContainer addSubview:self.progressView];
    
    self.progressLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 40, self.progressContainer.frame.size.width - 30, 20)];
    self.progressLabel.font = [UIFont systemFontOfSize:12];
    self.progressLabel.textAlignment = NSTextAlignmentCenter;
    [self.progressContainer addSubview:self.progressLabel];
    
    y += 90;
    self.installButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.installButton.frame = CGRectMake(20, y, width - 40, 55);
    [self.installButton setTitle:@"📲 تثبيت الآن" forState:UIControlStateNormal];
    [self.installButton setBackgroundColor:[UIColor systemBlueColor]];
    [self.installButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.installButton.titleLabel.font = [UIFont boldSystemFontOfSize:18];
    self.installButton.layer.cornerRadius = 15;
    [self.installButton addTarget:self action:@selector(installTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.scrollView addSubview:self.installButton];
    
    self.scrollView.contentSize = CGSizeMake(width, y + 100);
}

- (void)loadAppDetails {
    AppModel *item = (AppModel *)self.app;
    if (!item) return;
    self.nameLabel.text = item.name;
    self.versionLabel.text = [NSString stringWithFormat:@"إصدار: %@", item.version];
    self.bundleLabel.text = item.bundleId;
    self.descriptionView.text = item.appDescription;
    
    if (item.iconURL.length > 0) {
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:item.iconURL]];
            if (data) dispatch_async(dispatch_get_main_queue(), ^{ self.iconView.image = [UIImage imageWithData:data]; });
        });
    }
}

- (void)installTapped {
    AppModel *item = (AppModel *)self.app;
    if (!item.ipaURL) return;
    
    self.installButton.enabled = NO;
    self.installButton.alpha = 0.5;
    self.progressContainer.hidden = NO;
    self.progressLabel.text = @"جاري بدء التحميل...";
    
    [self downloadAndInstall];
}

- (void)downloadAndInstall {
    AppModel *item = (AppModel *)self.app;
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    
    self.currentDownloadTask = [session downloadTaskWithURL:[NSURL URLWithString:item.ipaURL] completionHandler:^(NSURL *location, NSURLResponse *response, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) { 
                self.progressLabel.text = @"خطأ في التحميل";
                [self resetUI]; 
                return; 
            }
            
            NSString *tempPath = [NSTemporaryDirectory() stringByAppendingPathComponent:@"install.ipa"];
            [[NSFileManager defaultManager] removeItemAtPath:tempPath error:nil];
            [[NSFileManager defaultManager] moveItemAtURL:location toURL:[NSURL fileURLWithPath:tempPath] error:nil];
            
            Class instClass = NSClassFromString(@"IPAInstaller");
            if (instClass) {
                id installer = [instClass performSelector:@selector(sharedInstaller)];
                SEL selector = NSSelectorFromString(@"installIPAAtPath:progress:completion:");
                
                NSMethodSignature *signature = [installer methodSignatureForSelector:selector];
                NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:signature];
                [invocation setTarget:installer];
                [invocation setSelector:selector];
                
                // تمرير المعاملات (Arguments)
                [invocation setArgument:&tempPath atIndex:2];
                
                typedef void (^ProgressBlock)(float, NSString *);
                ProgressBlock progress = ^(float p, NSString *s) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        self.progressView.progress = p;
                        self.progressLabel.text = s;
                    });
                };
                [invocation setArgument:&progress atIndex:3];
                
                typedef void (^CompletionBlock)(BOOL, NSError *);
                CompletionBlock completion = ^(BOOL success, NSError *err) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self resetUI];
                        if (success) self.progressLabel.text = @"تم التثبيت بنجاح!";
                    });
                };
                [invocation setArgument:&completion atIndex:4];
                
                [invocation retainArguments];
                [invocation invoke];
                
            } else {
                [self resetUI];
            }
        });
    }];
    [self.currentDownloadTask resume];
}

- (void)resetUI {
    self.installButton.enabled = YES;
    self.installButton.alpha = 1.0;
    self.progressContainer.hidden = YES;
}

@end