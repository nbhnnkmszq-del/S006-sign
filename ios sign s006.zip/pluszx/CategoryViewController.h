#import <UIKit/UIKit.h>

@interface CategoryViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) NSString *categoryName;
@property (nonatomic, strong) NSString *categoryID;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *apps;

@end