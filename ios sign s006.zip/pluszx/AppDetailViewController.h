#import <UIKit/UIKit.h>

@class AppModel; // تعريف مسبق للكلاس

@interface AppDetailViewController : UIViewController

// هذا المتغير الوحيد اللي نحتاجه عشان نمرر بيانات التطبيق من الصفحة الرئيسية
@property (nonatomic, strong) AppModel *app;

@end