//
//  zxlazerRootViewController.m
//  ZXLazerStore - الشاشة الرئيسية
//

#import "zxlazerRootViewController.h"
#import "AppDetailViewController.h"
#import "CategoryViewController.h"
#import "SettingsViewController.h"
#import "FilesViewController.h"
#import "SourcesViewController.h"

// تنفيذ نموذج التطبيق (التعريف الآن موجود في الهيدر)
@implementation AppModel
@end

@interface zxlazerRootViewController () <UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate>
@property (nonatomic, strong) UISearchBar *searchBar;
@property (nonatomic, strong) NSMutableArray<AppModel *> *apps;
@property (nonatomic, strong) NSMutableArray<AppModel *> *filteredApps;
@property (nonatomic, strong) UIActivityIndicatorView *loadingIndicator;
@property (nonatomic, strong) UIButton *settingsButton;
@property (nonatomic, strong) UIButton *sourcesButton;
@end

@implementation zxlazerRootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"ZX Lazer Store";
    self.view.backgroundColor = [UIColor systemBackgroundColor];
    
    [self setupNavigationBar];
    [self setupUI];
    [self loadApps];
}

- (void)setupNavigationBar {
    // زر الإعدادات
    self.settingsButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
    [self.settingsButton setImage:[UIImage systemImageNamed:@"gear"] forState:UIControlStateNormal];
    [self.settingsButton addTarget:self action:@selector(openSettings) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *settingsItem = [[UIBarButtonItem alloc] initWithCustomView:self.settingsButton];
    
    // زر المصادر
    self.sourcesButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
    [self.sourcesButton setImage:[UIImage systemImageNamed:@"server.rack"] forState:UIControlStateNormal];
    [self.sourcesButton addTarget:self action:@selector(openSources) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *sourcesItem = [[UIBarButtonItem alloc] initWithCustomView:self.sourcesButton];
    
    self.navigationItem.leftBarButtonItem = settingsItem;
    self.navigationItem.rightBarButtonItem = sourcesItem;
}

- (void)setupUI {
    CGFloat width = self.view.frame.size.width;
    CGFloat y = 0;
    
    // شريط البحث
    self.searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, y, width, 50)];
    self.searchBar.placeholder = @"ابحث عن تطبيق...";
    self.searchBar.delegate = self;
    [self.view addSubview:self.searchBar];
    
    y += 50;
    
    // مؤشر التحميل
    self.loadingIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleLarge];
    self.loadingIndicator.center = CGPointMake(width / 2, 200);
    self.loadingIndicator.hidesWhenStopped = YES;
    [self.view addSubview:self.loadingIndicator];
    
    // جدول التطبيقات (تم استخدام self.tableView المعرف في الهيدر)
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, y, width, self.view.frame.size.height - y) style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.rowHeight = 80;
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"AppCell"];
    [self.view addSubview:self.tableView];
}

- (void)loadApps {
    [self.loadingIndicator startAnimating];
    [self loadAppsFromLocalJSON];
}

- (void)loadAppsFromLocalJSON {
    self.apps = [NSMutableArray array];
    
    // سناب شات بلس
    AppModel *snap = [[AppModel alloc] init];
    snap.appId = @"com.snapchat.plus";
    snap.name = @"سناب شات بلس";
    snap.version = @"13.0.0";
    snap.bundleId = @"com.toyopagroup.picaboo";
    snap.iconURL = @"";
    snap.ipaURL = @"https://your-server.com/ipa/snapchat_plus.ipa";
    snap.appDescription = @"سناب شات بلس - جميع الميزات المدفوعة مفتوحة";
    snap.category = @"التواصل الاجتماعي";
    snap.downloadCount = 15234;
    [self.apps addObject:snap];
    
    // تيك توك بلس
    AppModel *tiktok = [[AppModel alloc] init];
    tiktok.appId = @"com.tiktok.plus";
    tiktok.name = @"تيك توك بلس";
    tiktok.version = @"34.0.0";
    tiktok.bundleId = @"com.zhiliaoapp.musically";
    tiktok.iconURL = @"";
    tiktok.ipaURL = @"https://your-server.com/ipa/tiktok_plus.ipa";
    tiktok.appDescription = @"تيك توك بلس - تحميل الفيديوهات بدون علامة مائية";
    tiktok.category = @"فيديو";
    tiktok.downloadCount = 8921;
    [self.apps addObject:tiktok];
    
    // يوتيوب بلس
    AppModel *youtube = [[AppModel alloc] init];
    youtube.appId = @"com.youtube.plus";
    youtube.name = @"يوتيوب بلس";
    youtube.version = @"19.0.0";
    youtube.bundleId = @"com.google.ios.youtube";
    youtube.iconURL = @"";
    youtube.ipaURL = @"https://your-server.com/ipa/youtube_plus.ipa";
    youtube.appDescription = @"يوتيوب بلس - بدون إعلانات، تشغيل الخلفية";
    youtube.category = @"فيديو";
    youtube.downloadCount = 34567;
    [self.apps addObject:youtube];
    
    self.filteredApps = [self.apps mutableCopy];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.loadingIndicator stopAnimating];
        [self.tableView reloadData];
    });
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.filteredApps.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"AppCell" forIndexPath:indexPath];
    
    for (UIView *subview in cell.contentView.subviews) {
        [subview removeFromSuperview];
    }
    
    AppModel *app = self.filteredApps[indexPath.row];
    
    UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(70, 10, 200, 25)];
    nameLabel.text = app.name;
    nameLabel.font = [UIFont boldSystemFontOfSize:16];
    [cell.contentView addSubview:nameLabel];
    
    UILabel *versionLabel = [[UILabel alloc] initWithFrame:CGRectMake(70, 35, 150, 20)];
    versionLabel.text = [NSString stringWithFormat:@"الإصدار %@", app.version];
    versionLabel.font = [UIFont systemFontOfSize:12];
    versionLabel.textColor = [UIColor secondaryLabelColor];
    [cell.contentView addSubview:versionLabel];
    
    UIImageView *iconView = [[UIImageView alloc] initWithFrame:CGRectMake(15, 15, 50, 50)];
    iconView.backgroundColor = [UIColor systemGray5Color];
    iconView.layer.cornerRadius = 12;
    iconView.clipsToBounds = YES;
    iconView.image = [UIImage systemImageNamed:@"app.fill"];
    [cell.contentView addSubview:iconView];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    AppModel *app = self.filteredApps[indexPath.row];
    AppDetailViewController *detailVC = [[AppDetailViewController alloc] init];
    detailVC.app = app; // هذي بتشتغل الحين لأننا أضفنا الخاصية في هيدر التفاصيل
    [self.navigationController pushViewController:detailVC animated:YES];
}

#pragma mark - UISearchBarDelegate

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    if (searchText.length == 0) {
        self.filteredApps = [self.apps mutableCopy];
    } else {
        self.filteredApps = [NSMutableArray array];
        for (AppModel *app in self.apps) {
            if ([app.name localizedCaseInsensitiveContainsString:searchText]) {
                [self.filteredApps addObject:app];
            }
        }
    }
    [self.tableView reloadData];
}

#pragma mark - Actions

- (void)openSettings {
    SettingsViewController *settingsVC = [[SettingsViewController alloc] init];
    [self.navigationController pushViewController:settingsVC animated:YES];
}

- (void)openSources {
    SourcesViewController *sourcesVC = [[SourcesViewController alloc] init];
    [self.navigationController pushViewController:sourcesVC animated:YES];
}

- (void)showAlert:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"حسناً" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end