//
//  SourcesViewController.m
//  ZXLazerStore - إدارة مصادر التطبيقات (السيرفرات)
//

#import "SourcesViewController.h"

@interface SourcesViewController () <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *sources;
@property (nonatomic, strong) UITextField *addSourceField;
@property (nonatomic, strong) UIButton *addButton;
@end

@implementation SourcesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"مصادر التطبيقات";
    self.view.backgroundColor = [UIColor systemBackgroundColor];
    
    [self setupUI];
    [self loadSources];
}

- (void)setupUI {
    CGFloat width = self.view.frame.size.width;
    CGFloat y = 0;
    
    // حقل إضافة مصدر
    self.addSourceField = [[UITextField alloc] initWithFrame:CGRectMake(20, y + 10, width - 100, 44)];
    self.addSourceField.placeholder = @"أدخل رابط المصدر...";
    self.addSourceField.borderStyle = UITextBorderStyleRoundedRect;
    self.addSourceField.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.addSourceField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.addSourceField.delegate = self;
    [self.view addSubview:self.addSourceField];
    
    self.addButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.addButton.frame = CGRectMake(width - 70, y + 10, 60, 44);
    [self.addButton setTitle:@"إضافة" forState:UIControlStateNormal];
    [self.addButton setBackgroundColor:[UIColor systemBlueColor]];
    [self.addButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.addButton.layer.cornerRadius = 8;
    [self.addButton addTarget:self action:@selector(addSource) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.addButton];
    
    y += 64;
    
    // جدول المصادر
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, y, width, self.view.frame.size.height - y) style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"SourceCell"];
    [self.view addSubview:self.tableView];
}

- (void)loadSources {
    // تحميل المصادر من UserDefaults
    NSArray *savedSources = [[NSUserDefaults standardUserDefaults] arrayForKey:@"app_sources"];
    
    if (savedSources) {
        self.sources = [savedSources mutableCopy];
    } else {
        // مصادر افتراضية
        self.sources = [NSMutableArray arrayWithObjects:
                        @"https://zx-lazer-store.com/api",
                        @"https://appdb.to/api",
                        @"https://ioshaven.com/api",
                        nil];
        [self saveSources];
    }
    
    [self.tableView reloadData];
}

- (void)saveSources {
    [[NSUserDefaults standardUserDefaults] setObject:self.sources forKey:@"app_sources"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)addSource {
    NSString *sourceURL = self.addSourceField.text;
    
    if (sourceURL.length == 0) {
        [self showAlert:@"خطأ" message:@"الرجاء إدخال رابط المصدر"];
        return;
    }
    
    // التحقق من صحة الرابط
    if (![sourceURL hasPrefix:@"http://"] && ![sourceURL hasPrefix:@"https://"]) {
        sourceURL = [NSString stringWithFormat:@"https://%@", sourceURL];
    }
    
    if (![self.sources containsObject:sourceURL]) {
        [self.sources addObject:sourceURL];
        [self saveSources];
        [self.tableView reloadData];
        self.addSourceField.text = @"";
        [self.addSourceField resignFirstResponder];
        [self showAlert:@"تم الإضافة" message:@"تمت إضافة المصدر بنجاح"];
        
        // تحديث التطبيقات من المصدر الجديد
        [self fetchAppsFromSource:sourceURL];
    } else {
        [self showAlert:@"موجود" message:@"المصدر موجود بالفعل"];
    }
}

- (void)fetchAppsFromSource:(NSString *)sourceURL {
    // جلب التطبيقات من المصدر
    NSString *appsURL = [sourceURL stringByAppendingString:@"/apps"];
    NSURL *url = [NSURL URLWithString:appsURL];
    
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                [self showAlert:@"خطأ" message:error.localizedDescription];
                return;
            }
            
            // معالجة البيانات
            // ...
        });
    }];
    
    [task resume];
}

- (void)deleteSourceAtIndex:(NSInteger)index {
    [self.sources removeObjectAtIndex:index];
    [self saveSources];
    [self.tableView reloadData];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.sources.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SourceCell" forIndexPath:indexPath];
    
    NSString *source = self.sources[indexPath.row];
    cell.textLabel.text = source;
    cell.textLabel.font = [UIFont systemFontOfSize:14];
    cell.imageView.image = [UIImage systemImageNamed:@"server.rack"];
    
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self deleteSourceAtIndex:indexPath.row];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSString *source = self.sources[indexPath.row];
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"المصدر"
                                                                   message:source
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"تحديث" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self fetchAppsFromSource:source];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)showAlert:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"حسناً" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    [self addSource];
    return YES;
}

@end