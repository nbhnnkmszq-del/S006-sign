#import <UIKit/UIKit.h>
#import "zxlazerAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        // الطريقة الصحيحة لاستدعاء الكلاس في Objective-C
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([zxlazerAppDelegate class]));
    }
}