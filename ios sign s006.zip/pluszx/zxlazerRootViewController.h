#import <UIKit/UIKit.h>

// 1. إخبار النظام بوجود كلاس اسمه AppModel
@class AppModel;

@interface zxlazerRootViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>

// 2. تعريف الـ tableView (تأكد من حذفه من ملف الـ .m سطر 30 كما اتفقنا)
@property (nonatomic, strong) UITableView *tableView;

// 3. مصفوفة التطبيقات
@property (nonatomic, strong) NSMutableArray *appsArray;

@end

// 4. تعريف الـ AppModel هنا يخلي كل الملفات الثانية تشوفه
@interface AppModel : NSObject
@property (nonatomic, strong) NSString *appId;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *version;
@property (nonatomic, strong) NSString *bundleId;
@property (nonatomic, strong) NSString *iconURL;
@property (nonatomic, strong) NSString *ipaURL;
@property (nonatomic, strong) NSString *appDescription;
@property (nonatomic, strong) NSString *category;
@property (nonatomic, assign) NSInteger downloadCount;
@end