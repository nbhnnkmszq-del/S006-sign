//
//  FilesViewController.h
//  ZXLazerStore - إدارة الملفات المحلية
//

#import <UIKit/UIKit.h>

@interface FilesViewController : UIViewController

// تعريف الدوال الأساسية إذا كنت تبي تستدعيها من ملفات ثانية
- (void)loadFilesAtPath:(NSString *)path;
- (NSString *)documentsPath;

@end