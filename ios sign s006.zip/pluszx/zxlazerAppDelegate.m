//
//  zxlazerAppDelegate.m
//  ZXLazerStore
//

#import "zxlazerAppDelegate.h"
#import "zxlazerRootViewController.h"

@implementation zxlazerAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    // إنشاء النافذة الرئيسية
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    
    // الشاشة الرئيسية
    zxlazerRootViewController *rootVC = [[zxlazerRootViewController alloc] init];
    self.navigationController = [[UINavigationController alloc] initWithRootViewController:rootVC];
    
    self.window.rootViewController = self.navigationController;
    [self.window makeKeyAndVisible];
    
    // تهيئة المتجر
    [self initializeStore];
    
    return YES;
}

- (void)initializeStore {
    NSLog(@"🔥 ZXLazerStore - متجر تطبيقات بلس");
    NSLog(@"📱 جاري تهيئة المتجر...");
    
    // إنشاء المجلدات اللازمة
    NSArray *folders = @[@"Downloads", @"Certificates", @"Signed", @"Backups"];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsPath = paths.firstObject;
    
    for (NSString *folder in folders) {
        NSString *folderPath = [documentsPath stringByAppendingPathComponent:folder];
        if (![[NSFileManager defaultManager] fileExistsAtPath:folderPath]) {
            [[NSFileManager defaultManager] createDirectoryAtPath:folderPath withIntermediateDirectories:YES attributes:nil error:nil];
            NSLog(@"📁 تم إنشاء المجلد: %@", folder);
        }
    }
    
    // التحقق من وجود TrollStore
    if ([self isTrollStoreInstalled]) {
        NSLog(@"✅ TrollStore موجود - التثبيت سيكون دائماً!");
    } else if ([self isAltStoreInstalled]) {
        NSLog(@"⚠️ AltStore موجود - يحتاج تجديد كل 7 أيام");
    } else {
        NSLog(@"📦 لا يوجد متجر بديل - سيتم حفظ الملفات يدوياً");
    }
    
    NSLog(@"✅ ZXLazerStore جاهز للعمل!");
}

- (BOOL)isTrollStoreInstalled {
    return [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"trollstore://"]];
}

- (BOOL)isAltStoreInstalled {
    return [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"altstore://"]];
}

@end