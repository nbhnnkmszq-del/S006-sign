#import <UIKit/UIKit.h>

@interface zxlazerAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
// تعريف النافيجيشن كنترولر ضروري جداً هنا
@property (strong, nonatomic) UINavigationController *navigationController;

// تعريف الدوال اللي استخدمتها في ملف الـ .m
- (void)initializeStore;
- (BOOL)isTrollStoreInstalled;
- (BOOL)isAltStoreInstalled;

@end