#import <UIKit/UIKit.h>

@interface SettingsViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UIDocumentPickerDelegate>

// لا نحتاج لتعريف الخصائص هنا لأننا عرفناها في ملف الـ m بشكل خاص
- (void)refreshCertificatesAndAnalyze;

@end