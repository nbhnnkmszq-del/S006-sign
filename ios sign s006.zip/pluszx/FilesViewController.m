//
//  FilesViewController.m
//  ZXLazerStore - إدارة الملفات المحلية
//

#import "FilesViewController.h"
#import <objc/message.h> // استدعاء مكتبة الرسائل لضمان التوافق

@interface FilesViewController () <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *files;
@property (nonatomic, strong) NSString *currentPath;
@property (nonatomic, strong) UIBarButtonItem *backButton;
@end

@implementation FilesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"الملفات المحلية";
    self.view.backgroundColor = [UIColor systemBackgroundColor];
    
    [self setupUI];
    [self loadFilesAtPath:[self documentsPath]];
}

- (void)setupUI {
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"FileCell"];
    [self.view addSubview:self.tableView];
    
    self.backButton = [[UIBarButtonItem alloc] initWithTitle:@"رجوع" style:UIBarButtonItemStylePlain target:self action:@selector(goBack)];
    self.navigationItem.leftBarButtonItem = self.backButton;
}

- (NSString *)documentsPath {
    return [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
}

- (void)loadFilesAtPath:(NSString *)path {
    self.currentPath = path;
    
    NSError *error;
    NSArray *contents = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:path error:&error];
    
    if (error) {
        [self showAlert:@"خطأ" message:error.localizedDescription];
        return;
    }
    
    self.files = [NSMutableArray array];
    
    for (NSString *item in contents) {
        NSString *itemPath = [path stringByAppendingPathComponent:item];
        BOOL isDirectory;
        [[NSFileManager defaultManager] fileExistsAtPath:itemPath isDirectory:&isDirectory];
        
        [self.files addObject:@{
            @"name": item,
            @"path": itemPath,
            @"isDirectory": @(isDirectory)
        }];
    }
    
    // ترتيب: المجلدات أولاً ثم الملفات
    [self.files sortUsingComparator:^NSComparisonResult(NSDictionary *obj1, NSDictionary *obj2) {
        BOOL isDir1 = [obj1[@"isDirectory"] boolValue];
        BOOL isDir2 = [obj2[@"isDirectory"] boolValue];
        
        if (isDir1 && !isDir2) return NSOrderedAscending;
        if (!isDir1 && isDir2) return NSOrderedDescending;
        return [obj1[@"name"] compare:obj2[@"name"]];
    }];
    
    [self.tableView reloadData];
}

- (void)goBack {
    if ([self.currentPath isEqualToString:[self documentsPath]]) {
        [self.navigationController popViewControllerAnimated:YES];
    } else {
        NSString *parentPath = [self.currentPath stringByDeletingLastPathComponent];
        [self loadFilesAtPath:parentPath];
    }
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.files.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"FileCell" forIndexPath:indexPath];
    
    NSDictionary *file = self.files[indexPath.row];
    BOOL isDirectory = [file[@"isDirectory"] boolValue];
    NSString *name = file[@"name"];
    
    cell.textLabel.text = name;
    
    if (isDirectory) {
        cell.imageView.image = [UIImage systemImageNamed:@"folder.fill"];
        cell.imageView.tintColor = [UIColor systemBlueColor];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    } else {
        if ([name hasSuffix:@".ipa"]) {
            cell.imageView.image = [UIImage systemImageNamed:@"app.fill"];
            cell.imageView.tintColor = [UIColor systemGreenColor];
        } else if ([name hasSuffix:@".p12"]) {
            cell.imageView.image = [UIImage systemImageNamed:@"lock.shield"];
            cell.imageView.tintColor = [UIColor systemOrangeColor];
        } else if ([name hasSuffix:@".mobileprovision"]) {
            cell.imageView.image = [UIImage systemImageNamed:@"checkmark.shield"];
            cell.imageView.tintColor = [UIColor systemPurpleColor];
        } else {
            cell.imageView.image = [UIImage systemImageNamed:@"doc.fill"];
            cell.imageView.tintColor = [UIColor systemGrayColor];
        }
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSDictionary *file = self.files[indexPath.row];
    BOOL isDirectory = [file[@"isDirectory"] boolValue];
    NSString *path = file[@"path"];
    
    if (isDirectory) {
        [self loadFilesAtPath:path];
    } else {
        [self handleFile:path];
    }
}

- (void)handleFile:(NSString *)filePath {
    NSString *fileName = [filePath lastPathComponent];
    
    if ([fileName hasSuffix:@".ipa"]) {
        [self installIPA:filePath];
    } else if ([fileName hasSuffix:@".p12"] || [fileName hasSuffix:@".mobileprovision"]) {
        [self importCertificate:filePath];
    } else {
        [self shareFile:filePath];
    }
}

- (void)installIPA:(NSString *)ipaPath {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"تثبيت التطبيق"
                                                                   message:@"هل تريد تثبيت هذا التطبيق؟"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"تثبيت" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
        Class installerClass = NSClassFromString(@"IPAInstaller");
        if (installerClass) {
            id installer = [installerClass performSelector:@selector(sharedInstaller)];
            SEL installSelector = NSSelectorFromString(@"installIPAAtPath:progress:completion:");
            
            NSMethodSignature *sig = [installer methodSignatureForSelector:installSelector];
            NSInvocation *inv = [NSInvocation invocationWithMethodSignature:sig];
            [inv setTarget:installer];
            [inv setSelector:installSelector];
            
            // تمرير ipaPath مع الـ casting المناسب لمنع أخطاء الـ compiler
            NSString *ipaPathArg = ipaPath; 
            [inv setArgument:(void *)&ipaPathArg atIndex:2];
            
            id progress = nil;
            [inv setArgument:(void *)&progress atIndex:3];
            
            // البلوك الخاص بالانتهاء
            id completion = ^(BOOL success, NSError *error) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (success) {
                        [self showAlert:@"تم التثبيت" message:@"تم تثبيت التطبيق بنجاح"];
                    } else {
                        [self showAlert:@"فشل التثبيت" message:error.localizedDescription];
                    }
                });
            };
            [inv setArgument:(void *)&completion atIndex:4];
            
            // ضروري جداً لتنفيذ العملية
            [inv retainArguments];
            [inv invoke];
            
        } else {
            [self shareFile:ipaPath];
        }
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"إلغاء" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)importCertificate:(NSString *)certPath {
    NSString *documentsPath = [self documentsPath];
    NSString *certsPath = [documentsPath stringByAppendingPathComponent:@"Certificates"];
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:certsPath]) {
        [[NSFileManager defaultManager] createDirectoryAtPath:certsPath withIntermediateDirectories:YES attributes:nil error:nil];
    }
    
    NSString *destPath = [certsPath stringByAppendingPathComponent:[certPath lastPathComponent]];
    
    NSError *error;
    if ([[NSFileManager defaultManager] fileExistsAtPath:destPath]) {
        [[NSFileManager defaultManager] removeItemAtPath:destPath error:nil];
    }
    
    [[NSFileManager defaultManager] copyItemAtPath:certPath toPath:destPath error:&error];
    
    if (error) {
        [self showAlert:@"خطأ" message:error.localizedDescription];
    } else {
        [self showAlert:@"تم الاستيراد" message:@"تم استيراد الشهادة بنجاح"];
    }
}

- (void)shareFile:(NSString *)filePath {
    NSURL *fileURL = [NSURL fileURLWithPath:filePath];
    UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:@[fileURL] applicationActivities:nil];
    [self presentViewController:activityVC animated:YES completion:nil];
}

- (void)showAlert:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"حسناً" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end